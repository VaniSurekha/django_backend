from django.apps import AppConfig


class TransferevalConfig(AppConfig):
    name = 'TransferEval'
